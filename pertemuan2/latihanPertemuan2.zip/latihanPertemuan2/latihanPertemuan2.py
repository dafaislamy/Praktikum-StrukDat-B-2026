'''
SOAL 1

Diberikan sebuah list angka:
angka = [10, 20, 30, 40, 50]
1. Tambahkan angka 60 ke dalam list.
2. Hapus angka 20 dari list.
3. Tampilkan angka tertinggi dan terendah
4. Hitung rata-rata angka setelah perubahan data
5. Tampilkan seluruh isi list setelah perubahan.
'''

angka = [10, 20, 30, 40, 50]
angka.append(60) #menambahkan angka 60  ke dalam list
print(angka)

angka.remove(20) #hapus angka 20 dari list
print(angka)

nilaiMax = max(angka)
nilaiMin = min(angka)
print('Angka tertinggi (max) pada data adalah', max(angka)) #menampilkan angka tertinggi setelah perubahan data
print('Angka terkecil (min) pada data adalah', min(angka)) #menampilkan angka terendah setelah perubahan data

jumlah = 0
for x in angka:
    print(x)
    jumlah = jumlah + x
rata_rata = jumlah / 5 #menghitung rata-rata angka setelah perubahan data
print(rata_rata)

print(angka) #menampilkan seluruh isi list perubahan data


'''
SOAL 2

Diberikan sebuah tuple data mahasiswa:
mahasiswa = ("A001", "Budi", "Informatika")
1. Tampilkan nama mahasiswa dari tuple tersebut.
2. Tampilkan seluruh isi tuple menggunakan perulangan for.
3. Jelaskan satu alasan mengapa tuple tidak bisa diubah.
'''

mahasiswa = ('A001', 'Budi', 'Informatika')
print(mahasiswa[1])

for x in mahasiswa:
    print(x)



'''
SOAL 3
'''

kelas_A = {'Struktur Data', 'Basis Data', 'AI', 'Pemrograman Web'}
kelas_B = {'Struktur Data', 'Machine Learning', 'AI', 'Cloud Computing'}

duaKelas = kelas_A & kelas_B
print(duaKelas)

hanyaA = kelas_A - kelas_B
print(hanyaA)

kelasUnik = kelas_A ^ kelas_B
print(kelasUnik)


'''
SOAL 4
'''

mahasiswa = {
    "A001": {"nama": "Budi", "prodi": "Informatika", "ipk": 3.45},
    "A002": {"nama": "Siti", "prodi": "Sistem Informasi", "ipk": 3.20},
    "A003": {"nama": "Andi", "prodi": "Informatika", "ipk": 3.75}
}

